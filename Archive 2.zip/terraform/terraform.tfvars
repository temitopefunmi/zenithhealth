resource_group_name = "rg-Zenith-Health"
mgmt_resource_group_name = "rg-zenith-mgmt"
location            = "westeurope"
app_name            = "zht-dashboard"
github_repo         = "temitopefunmi/zenith-health" # Change 'username/repo-name' to your actual GitHub repository in the format 'username/repo-name'
storage_account_name  = "zenithtfstate1772695633" # Change to a unique name if you want to create a new storage account for Terraform state