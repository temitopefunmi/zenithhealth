import { NextResponse } from "next/server";
import { executeQuery } from "@/lib/db";
import { requireRole } from "@/lib/auth-helpers";

export async function GET() {
  try {
    // Ensure only nurses can access this endpoint
    await requireRole("NURSE");

    const result = await executeQuery(`
      SELECT
        (
          SELECT COUNT(DISTINCT patientId)
          FROM NurseAssignments
        ) AS assignedPatients,

        (
          SELECT COUNT(*)
          FROM MedicationAdministration
        ) AS medicationTasks,

        (
          SELECT COUNT(DISTINCT patientId)
          FROM Vitals
        ) AS vitalsMonitored
    `);

    const stats = result.recordset[0];

    return NextResponse.json({
      assignedPatients: Number(stats.assignedPatients || 0),
      medicationTasks: Number(stats.medicationTasks || 0),
      vitalsMonitored: Number(stats.vitalsMonitored || 0),

      // Placeholder until we create an Equipment table
      equipmentStatus: "9/9"
    });
  } catch (err) {
    console.error(err);

    return NextResponse.json(
      {
        error: "Failed to load nurse dashboard metrics"
      },
      {
        status: 500
      }
    );
  }
}